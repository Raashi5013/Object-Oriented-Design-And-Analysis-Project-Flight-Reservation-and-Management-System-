package com.flight.booking.security;

public class SecurityConstants {
    public static final long JWT_EXPIRATION = 7000000;
    public static final String JWT_SECRET = "nOPI1UgckLHpr84oHsS1/UlD4cwmFuYBnxTFLH223sXgIq6t32z0X/m1YFQfYpd6P5pgi/+e20pBQEJYGp+dmA==";
}
